# Skill Evals

How this repo measures whether its skills actually work: that they **trigger** when they should, **stay distinct** from each other, and **change agent behavior** the way each skill promises.

## Prior art (and what we adopted)

There is no single settled community standard for evaluating `SKILL.md` skills, but two approaches lead:

- **Anthropic's skill-creator v2** defines a per-skill `evals.json` (prompt + `expectations[]`, graded from the transcript) plus trigger-accuracy testing of descriptions against sample prompts. We adopt its [`evals.json` schema](https://github.com/anthropics/skills/tree/main/skills/skill-creator) for our behavioral tier and add one optional `kind` field to select the artifact being graded.
- **Superpowers** (obra) tests skills with bash + `claude -p` + prompt fixtures and grader scripts. Our behavioral runner follows the same headless-`claude` pattern, with the grading rubric drawn from `expectations[]`.

What neither provides is a **deterministic, CI-safe** check for a multi-skill *catalog* — does each skill's description carry the vocabulary users actually say, and do two skills' descriptions collide? That's Tier 2 below, and it's this repo's addition.

## The three tiers

| Tier | What it checks | Runs | Cost |
|---|---|---|---|
| 1. Structural | Frontmatter, naming, required sections, layout and line budget, `references/` links, command parity, artifact paths, manifest versions | CI (`validate-skills.js`, `validate-reference-links.js`, `validate-commands.js`, `validate-artifact-paths.js`, `validate-versions.js`) | Free |
| 2. Trigger & routing | Positive prompts rank their skill top-k; negative prompts don't; no two descriptions near-collide | CI (`run-evals.js --min-rank1 95`) | Free |
| 3. Behavioral | An agent following the skill satisfies its `expectations[]` | On demand (`run-evals.js --behavioral`) | Tokens |

Tier 2 is a **lexical approximation** of routing (stemmed TF-IDF over descriptions). It cannot judge semantics — that's Tier 3's job — but it catches the two failure modes that dominate real trigger bugs: a description missing the vocabulary users say (false negative), and an over-broad description that outranks the right skill (false positive). A Tier-2 failure usually means *fix the description*, not the eval.

## Running

```bash
# Tier 2 — deterministic, runs in CI
node scripts/run-evals.js
node scripts/run-evals.js --min-rank1 95  # enforce the current routing floor

# Tier 3 — behavioral, runs each eval through headless claude, then grades it
node scripts/run-evals.js --behavioral test-driven-development            # spends tokens
node scripts/run-evals.js --behavioral test-driven-development --dry-run  # prints the plan only
node scripts/run-evals.js --behavioral test-driven-development --eval 1   # run only case 1
```

`--eval <id>` selects one behavioral case by its integer `id` (including `0`)
and also works with `--dry-run`. Unknown or invalid IDs fail before execution;
omitting the selector runs every case as before.

Tier 3 supports two behavioral artifact kinds. `execution` is the default: each eval runs in a throwaway git repository, real project inputs from `files[]` are materialized out of `evals/fixtures/` and committed as the baseline, and the grader judges the full `--output-format stream-json --verbose` execution trace, including tool calls. `dialogue` is reserved for skills whose deliverable is the conversation itself; it needs no fixture, and the grader judges the assistant's conversational turns without requiring file edits or commands. Claiming `dialogue` is a human-reviewed exemption, not a general escape hatch for execution skills.

The executor can read a separate temporary copy of the skill directory and the
shared root `references/`, with their repository-relative layout preserved.
Its supplied skill text names that base directory. These resources stay outside
the fixture's Git baseline and are removed after the run. Availability alone does
not prove use: add a trace expectation when opening a reference matters.

The executor runs with an explicit permission mode (`--permission-mode acceptEdits` plus a pre-approved tool list) so execution evals can genuinely edit files, run commands, inspect diffs, and make commits rather than being denied and narrating instead. Traces are fenced as untrusted data in the grader prompt and piped to the grader over stdin (they can be megabytes; argv would hit the OS argument-size limit), executor and grader calls carry timeouts, and grader output is validated as JSON before being written to `evals/results/` (gitignored) in skill-creator's `grading.json` shape. Discipline skills also include pressure cases for time pressure, sunk cost, and authority pressure; these verify that the workflow still holds when the prompt argues for skipping it.

Only completed executor streams reach the grader: require an explicit successful
terminal result, no permission denials, and a returned observation for every tool
call. A returned failed probe may still recover before completion. Failed or
incomplete executions retain `.execution.raw.txt` and `.execution.error.txt`
beside the case's result slot, produce no score, and do not stop later cases.
These latest-attempt diagnostics are cleared when that case is rerun.

### Record once, regrade a changed rubric

Use `--record` to keep a generation for later grading, and `--model` to pin the
requested executor and grader model:

```bash
node scripts/run-evals.js --behavioral documentation-and-adrs --record --model <model>
node scripts/run-evals.js --regrade <printed-record-path> --rubric evals/cases/documentation-and-adrs.json --model <model>
```

Recording is opt-in. Each eval writes a unique `*.record.json` in `evals/results/`
**before** calling the grader. It contains the exact stream-json trace, skill
text, original eval, generation timestamp, requested model, observed executor
model (when present), Claude Code version (or `null` if unavailable), and a
SHA-256 digest of that evidence. The existing latest-run `*.grading.json` output
is still written as usual. An execution that stops incomplete is not graded
and saves no record. These local records contain full transcripts and
may include fixture data; review them before sharing.

Records list what was staged for the executor: `staged` holds every file
copied from the skill directory and the root `references/`, by its path in the
repository layout, with a SHA-256 of its bytes, taken before the executor runs.
This describes files supplied by the harness, not files the agent actually read,
and it is not an inventory of arbitrary filesystem or network access. Replay
requires the list to include the skill's `SKILL.md`, matching the recorded skill
text, and only paths under `skills/<name>/` or `references/`.

Regrade uses the full case-file format above and selects the recorded skill and
eval ID. Only `expectations` and `expected_output` may differ; the grader still
scores `expectations`, as in a normal run. A changed task or modified record is
rejected before any Claude invocation. The digest detects accidental changes,
not authenticity: someone who edits both the evidence and digest can replace it.
Replay uses the saved evidence without loading today's skill or fixtures, and
labels the result **historical**, not a new test of the current skill. Holding
the transcript fixed removes generation variance; LLM grading can still vary.

Every grading attempt gets its own `*.record.json.attempt-<id>.json` beside the
record, containing the rubric, model request, CLI version, timestamp, raw output
and parsed grade, or an error. The grader's resolved model remains `unknown`
because its text response does not identify it. A replay never overwrites the
record, earlier attempts, or latest-run grading files. If grading fails, retry
with `--regrade` without paying for generation again. `--dry-run` validates and
prints the plan without invoking Claude or writing files. Unrecorded older runs
cannot be reconstructed as records.

## Plugin evals (Claude Code)

`claude plugin eval` (Claude Code 2.1.269 or later) loads the whole plugin, every skill at once, runs the cases under `evals/plugin/`, and scores each case with and without the plugin. It complements Tier 2 rather than replacing it: Tier 2 checks that a description carries the vocabulary users say; this checks that Claude Code's own router picks the skill on a natural prompt, and what the skill adds to the reply (the `Δ` column).

```bash
claude plugin eval . --no-publish                                          # every case, both arms, 3 runs each
claude plugin eval . --case code-review-fires --runs 1 --ablation none     # one cheap iteration on one case
```

A case is a directory holding `prompt.md` (frontmatter: turn and tool limits; body: the prompt, sent verbatim) and one grader per file under `graders/`. Reports land in `evals/plugin/results/<timestamp>/`, already gitignored. Every run and every `llm` grader is a real model call on your account, so this runs on demand and never in CI, like Tier 3.

Two rules keep it honest. The manifest's `experimental.evals` key scopes the scan to `evals/plugin/`, so a fixture elsewhere under `evals/` is never read as a case. And a `tool_used: Skill` grader only says whether the skill fired; in a two-arm run it is excluded from the score, so pair it with a grader on the reply itself. `code-review-fires` shows the pattern: the fired indicator, a free `regex` grader that looks for the skill's severity taxonomy (Critical, Required, Nit, Optional, Consider, FYI) used as a heading or as a label, and one `llm` judge on the planted off-by-one. `code-review-stays-quiet` is the precision check: the review skill must not fire on a test-first request, and its `Δ` is expected to be 0; a second, unscored indicator records whether test-driven-development fires instead.

What the first runs taught (Claude Code 2.1.278, claude-opus-5). Skill invocation is stochastic: the review skill fired in 5 of 7 runs on the phrasing the case uses, and test-driven-development fired in 2 of 7 runs on the test-first prompt, so read `Δ` and the report rather than the exit code, or pass `--threshold 0.8` as the CI example in the docs does. In one run the review skill did not fire and the reply still used its severity taxonomy as headings, which no baseline run did in nine; the loaded skill descriptions may shape the reply even without an invocation. Phrasing matters, and the description is the lever. With the original description, "Review this diff before I merge it", "Can you do a proper code review of this change before I merge it?" and "Review this pull request for me before it goes into main" rarely fired the skill; the model reviewed the diff on its own, competently but without the verdict, the severity tiers or the five-axis pass. Describing what the skill adds did not help, and neither did naming diffs and pull requests on their own; what made the difference was saying that the skill applies even when the diff is pasted inline, which is the case the model was treating as "I can just do this myself". On claude-opus-5-5 with the model pinned, that one clause took the four review phrasings from 7 of 27 fires to 21 of 27, left the nine adjacent must-not-fire prompts at 0 of 27 both ways, and moved the plainest phrasing from 0 of 9 to 3 of 9, so it is better, not solved. `code-review-stays-quiet-on-commit-message` guards that clause: a pasted diff with a commit-message request must not fire the review skill. One practical rule from the same day: pin `--model` and record the Claude Code version whenever you report numbers, because the CLI updates itself and the default model changed twice between morning and evening. Since #714 the lifecycle commands are user-invoked only, so the model reaches a skill directly, and a `tool_used: Skill` grader matches the skill name alone.

The same lever, applied to test-driven-development (claude-opus-5-5 pinned, six runs per prompt). With the original description, "Add unit tests for this function", "Fix this bug ... here is the function" and "Change this function so that size can never exceed 100" fired the skill 0 of 6 each, while the process-shaped "Write a failing test for this bug before we fix it" fired 6 of 6: the model wrote the tests or the fix directly. Here the tail alone was not enough; what worked was naming the three requests and saying the skill applies even when the code is pasted inline and the request does not mention tests. That clause took the four prompts from 6 of 24 to 19 of 24 (add tests 6 of 6, fix a bug 6 of 6, change behavior 1 of 6), and left eight adjacent must-not-fire prompts at 0 of 24 under every variant tried. The one-line behavior change is the floor: the trace shows a single-turn edit with no tool call, the model does not consider a procedure for it. `tdd-fires-on-pasted-bug` and `tdd-stays-quiet-on-debug` are the pair for that clause: the first checks the skill fires on a pasted bug and that the reply reproduces it with a failing test before the fix, the second checks that a "what broke" question with a diff does not pull the TDD skill in. On the first, the skill fired in every run, but the reply put the failing test before the fix in 2 of 4 runs with the plugin and 0 of 3 without: the judge is strict on purpose, since that order is what the skill adds, and the misses (fix first, then a test with a note that it would have failed on the old code) are an adherence gap of the skill in a session with no shell to run anything, not a routing one.

The same lever, applied to code-simplification (claude-opus-5-5 pinned, Claude Code 2.1.296, three runs per prompt per description). With the original description, "Simplify this function, it works but it is hard to read", "Clean this up, it works but it has grown hard to follow" and "Reduce the nesting in this function", each with the function pasted, fired the skill 0 of 3: the model rewrote the code directly. The clause names those three requests and says the skill applies even when the code is pasted inline and nothing else needs to change. It took the three prompts from 0 of 9 to 8 of 9 (simplify 3 of 3, clean up 2 of 3, nesting 3 of 3) and left five adjacent must-not-fire prompts with pasted code (make it fast, add tests, review, commit message, what broke) at 0 of 15 both ways. `simplify-fires-on-pasted-function` and `simplify-stays-quiet-on-make-it-fast` are the pair for that clause. The first grades what the skill adds on a pasted `normalizeTags`: both arms produce the same shorter function, and the obvious rewrite reads a Set the original would have ignored, so the judge checks that the reply either keeps the original's result for every input or says where it differs, and that it tells the user to run the existing tests before swapping it in. With the plugin the skill fired 3 of 3; two replies disclosed the difference and one kept the index loop to avoid it, and all three asked for a test run. Without it, one reply disclosed the difference, two claimed the same results for every input, and none asked for a test run, so the judge passed 3 of 3 with and 0 of 3 without. A first wording of that grader, which failed any behavior change outright, scored the honest replies 0 of 3 and the silent ones 3 of 3, so the thing to grade is the disclosure and the verification step, not bare equivalence. The second case checks that a speed complaint about pasted code does not pull the simplification skill in.

Re-run after #714 made the lifecycle commands user-invoked only (claude-opus-5-5 pinned, Claude Code 2.1.312, three runs per case, then six on the two that moved). The command names were dropped from every `tool_used: Skill` pattern, since a `Skill` call naming a command can no longer happen. `code-review-fires` fired 3 of 3 and `simplify-fires-on-pasted-function` 6 of 6; every stays-quiet case stayed at 0. `tdd-fires-on-pasted-bug` fired 1 of 6, against 6 of 6 when #678 measured it on 2.1.283, and five of the six runs were single-turn direct answers with no tool call at all. That is not #714: with `disable-model-invocation` removed from `/test` for the measurement, the same case fired 0 of 6. The clause has not changed; the router under it has, between 2.1.283 and 2.1.312. Treat the test-driven-development numbers above as dated to their CLI version, which is what pinning the version is for.

The same lever, applied to git-workflow-and-versioning (claude-opus-5-5 pinned, Claude Code 2.1.312, three runs per prompt per description). With the original description, "write me a commit message for this diff", "write the changelog entry for this diff" and "split this into commits for me", each with the diff pasted, fired the skill 0 of 3, 0 of 3 and 1 of 3: the model wrote the message directly, in one turn. The clause names the three requests and says the skill applies even when the diff is pasted inline and the message seems easy to write from it. It took the three prompts to 6 of 6, 3 of 3 and 3 of 3, and left three adjacent must-not-fire prompts with the same pasted diff (review, add tests, simplify) at 0 of 9, with "what broke?" on a pasted diff at 0 of 6. A longer clause that also spelled out what the message must contain fired the same but pushed the skill's own "Resolve the merge conflict on this feature branch" to rank 2 in Tier 2, so the shorter one stays. `gitflow-fires-on-commit-message` and `gitflow-stays-quiet-on-what-broke` are the pair. The first pastes a diff that carries two unrelated changes, a retry loop and a formatting helper, and the judge grades what the skill adds: a subject with a type, a body that says why rather than restating the diff, and the two concerns in separate commits. Both arms notice the split; with the plugin every reply also uses a typed subject and a why body, and without it none does, so the judge passed 5 of 6 with and 0 of 3 without. The second case checks that a diff pasted with a "what broke?" question does not pull the git skill in.

The test-driven-development clause, re-tuned for the current router (claude-opus-5-5 pinned, six runs per wording on Claude Code 2.1.319 unless noted). The #678 clause fired the pasted-bug prompt 6 of 6 on 2.1.283 and 1 of 12 on 2.1.312, every miss a single-turn direct fix with no tool call; #756 ruled out #714. Five wordings were measured on 2.1.319, and only one moves it: the clause saying the answer may look obvious from reading the code, followed by the sentence that the skill writes the failing test first and changes the function second, never the change alone, fired 6 of 6 (9 of 9 on 2.1.312). Every attempt to keep that idea inside the trigger instead failed: the clause without the sentence fired 0 of 6, "the fix looks too obvious to need a test" 1 of 6, "the fix looks obvious, since the failing test comes before the fix" 0 of 6, and the sentence moved into the opening what-it-does clause 2 of 6. Under the kept wording, `tdd-stays-quiet-on-refactor` ("Refactor this function so it is easier to read" with the function pasted) stayed at 0 of 6, `simplify-fires-on-pasted-function` still fired 6 of 6 with its judge 6 of 6, and `tdd-stays-quiet-on-debug` stayed at 0 of 6. The offline Tier 2 ranker puts TDD narrowly ahead of code-simplification on that refactor prompt (0.185 to 0.151); the live router does not follow it, and the stays-quiet case now guards that boundary. On the graded pair the judge passed 3 of 6 with the plugin; the misses are the fix shown before the test, the adherence gap #678 recorded.

The review clause, extended for the plainest phrasing (claude-opus-5-5 pinned, Claude Code 2.1.319). The #612 clause left "Review this diff before I merge it" at 3 of 9; on 2.1.319 it is 3 of 12, the model reviewing the diff directly with no verdict and no severity labels. `code-review-fires-on-plain-request` is that prompt with the diff pasted. Adding that the review may look quick to do from reading the diff took it to 12 of 12. A version that also said what the skill adds (a verdict and a severity on every finding) scored the same 12 of 12, so it was dropped: the trigger carries it, which fits what #612 found about describing what the skill adds. Under the kept clause the nine adjacent requests #612 measured, each with the same diff pasted (simplify, debug, commit message, changelog, security check, performance, add tests, implement, explain), stayed at 0 of 27; both stays-quiet cases stayed at 0 of 3; and `code-review-fires` stayed at 3 of 3 with its severity labels and the planted off-by-one.

The same lever, applied to debugging-and-error-recovery (claude-opus-5-5 pinned, Claude Code 2.1.312, three runs per prompt per description). With the original description, "what broke?" with the diff pasted, "why does this throw?" with the stack trace and function pasted, and "this worked yesterday and now returns the wrong total" with the function pasted fired the skill 0 of 3 each: the model answered in one turn with no tool call. A first clause, naming the request and saying the skill applies even when the code, diff or error output is pasted inline, moved almost nothing on this CLI (0 of 6, 0 of 3, 1 of 3). What worked was adding that the cause may look obvious from reading it, and what the reply must still do: name the cause, make the minimal fix, say how to confirm it. That clause took the three prompts to 9 of 9, 3 of 3 and 3 of 3, and left four adjacent must-not-fire prompts with the same pasted code (add tests, simplify, review, make it fast) at 0 of 12 under every variant. `debugging-fires-on-pasted-diff` and `debugging-stays-quiet-on-review` are the pair: the first is the pasted pagination diff with "what broke?", the second the same diff as a review request, which must not pull the debugging skill in (0 of 6, both arms). The judge on the first grades what the skill adds: the cause named precisely, the one-token fix, and a way to confirm it. Both arms name the cause and the fix; with the plugin every reply also says to re-run the failing test or add a boundary test, and without it none does, so the judge passed 3 of 3 with and 0 of 3 without. A first judge that also required a worked reproduction and a regression assertion failed both arms 0 of 3, hiding that difference, so the thing to grade is the confirmation step the baseline skips.

## Eval case format

One file per skill: `evals/cases/<skill-name>.json`.

```json
{
  "skill_name": "test-driven-development",
  "trigger": {
    "positive": [
      { "prompt": "Write a failing test for this bug before fixing it", "top_k": 3 }
    ],
    "negative": [
      { "prompt": "Update the architecture diagram in the docs", "owner": "documentation-and-adrs" }
    ]
  },
  "evals": [
    {
      "id": 1,
      "kind": "execution",
      "prompt": "Finance filed the reconciliation bug written up in BUG.md. Fix it.",
      "expected_output": "A failing reproduction test for the lost-cent case, a fix preserving both README invariants (exact sum, earliest-shares fairness), the fairness invariant covered by its own test, full suite passing",
      "files": [
        "test-driven-development"
      ],
      "expectations": [
        "A test reproducing the lost-cent case from BUG.md is added and shown failing before src/split.js is modified",
        "The final implementation satisfies the full README fairness invariant (leftover cents go to the earliest shares): splitCents(10000, 3) returns [3334, 3333, 3333] as BUG.md expects and splitCents(100, 7) returns [15, 15, 14, 14, 14, 14, 14] as the README example shows; dumping the whole remainder on a single share would violate both",
        "The fairness invariant from the README has its own test case in the suite on an input with remainder of at least 2 (such as splitCents(100, 7)), where dumping the whole remainder on one share would fail it, beyond the reported lost-cent case",
        "The full suite is run with the repository's own command after the fix"
      ]
    }
  ]
}
```

- `evals[]` uses skill-creator's core schema (`id`, `prompt`, `expected_output`, optional `files[]`, `expectations[]`) plus this repository's optional `kind`. `kind` must be `execution` or `dialogue` and defaults to `execution` for compatibility. Execution evals require non-empty `files[]`; paths are relative to `evals/fixtures/` and may name a file or project directory. Dialogue evals may omit `files[]` because the transcript is the artifact. Expectations are verifiable statements a grader checks against the relevant artifact — behaviors, not phrasings.
- `trigger` is this repo's extension. `positive` prompts are realistic user asks that should route here (`top_k` defaults to 3; tighten to 1 for a skill's signature ask). `negative` prompts belong to a *different* skill; this skill must not rank first for them. Declare that skill in `owner` where you can: the runner then asserts the owner **outranks** this skill, turning the negative into a real pairwise routing test instead of one that can pass vacuously when the prompt matches nothing.

**Writing good trigger prompts:** paraphrase how users actually talk; don't copy the description (that's gaming the eval). If a realistic prompt can't rank because the description lacks its vocabulary, that is a real finding — improve the description.

## Adding a skill

Every skill ships with an eval file. When you add `skills/<name>/`, add `evals/cases/<name>.json` with at least 3 positive triggers, 2 negative triggers, and 1 behavioral eval. Execution evals must be backed by `evals/fixtures/<name>/`; use `kind: "dialogue"` only when the skill's deliverable is genuinely the conversation itself. Missing case files, incomplete case counts, unknown kinds, invalid fixture paths, and absent required fixtures are CI errors.

## Metrics to watch

The Tier-2 run prints a **trigger rank-1 rate** (share of positive prompts that rank their skill first, not merely top-k). CI runs with `--min-rank1 95`, leaving useful headroom below the checked-in 100% baseline so an unrelated description edit does not immediately turn CI red. Raise the floor as routing improves; never lower it to make a regression pass. Falling numbers mean descriptions are drifting toward each other. The collision check errors at ≥75% pairwise description similarity and warns at ≥50%. When these evals surface a description-vocabulary gap (see [#351](https://github.com/addyosmani/agent-skills/issues/351) for the original examples), fix the description, not the prompt.
